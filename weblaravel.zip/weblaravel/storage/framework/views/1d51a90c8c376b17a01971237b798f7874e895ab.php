<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
    <h1 style="color: green"><?php echo e($message); ?></h1>
    <?php elseif($message = Session::get('error')): ?>
    <h1 style="color: red"><?php echo e($message); ?></h1>
    <?php endif; ?>
    <div class="container" style="margin-top: 20px ">
    <h1>Data Material Bangunan</h1>
        <div style="margin-top: 20px ">
            <div class="row">
                <div class="col-md-4">
                    <div class="container">
                    <div class="col-mt-2">
                    <form action="" method="get">
                    <select name="id">
                        <option value="">Semua</option>
                        <option value="001">001</option>
                        <option value="002">002</option>
                        <option value="003">003</option>
                        <option value="004">004</option>
                    </select>
                    <input type="submit" class="btn btn-sm btn-primary " value="Cari">
                    <a class="btn btn-info float-right " href="<?php echo e(route('material.create')); ?>">Tambah Data </a><br><br>
                    </div>
                    </div>
                    

                    </form><br><br>

                </div>
            </div>
        </div>

                    <div class="body">
                        <table class="table table-striped table-dark">
                            <thead class="thead-light">
                                <tr>
                                    <th><b>No.</b></th>
                                    <th><b>Kode Material</b></th>
                                    <th><b>Nama Material</b></th>
                                    <th><b>Opsi</b></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($m['no']); ?></td>
                                        <td><?php echo e($m['id']); ?></td>
                                        <td><?php echo e($m['nama']); ?></td>
                                        <td><a class="btn btn-primary" href="<?php echo e(route('material.show', $m['no'])); ?>">Lihat</a>
                                        <a class="btn btn-success" href="<?php echo e(route('material.edit',$m['no'])); ?>">Ubah</a> <br><br>
                                        <form action="<?php echo e(route('material.destroy', $m['no'])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" value="<?php echo e($m['nama']); ?>" name="name">
                                            <input class="btn btn-danger"type="submit" value="Hapus" onclick="return alert('Apakah anda yakin?')">
                                        </form>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                        </div>
                        <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\weblaravel\resources\views/material.blade.php ENDPATH**/ ?>