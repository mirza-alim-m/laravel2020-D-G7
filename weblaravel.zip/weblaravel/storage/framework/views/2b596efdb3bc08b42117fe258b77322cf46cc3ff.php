<?php $__env->startSection('content'); ?>


<div class="container">

    <div class="row">

         
            <h1 class="mt-3">Daftar Material Bangunan</h1>
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Material</th>
                    <th scope="col">Kode Material</th>
                    <th scope="col">Deskripsi</th>
                    <th scope="col">Opi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($mtr->nama); ?></td>
                        <td><?php echo e($mtr->kode); ?></td>
                        <td><?php echo e($mtr->deskripsi); ?></td>
                        <td>
                        <a href="<?php echo e($mtr->id); ?>/edit" class="btn btn-success">Ubah</a>
                        <form action="/materials/<?php echo e($mtr->id); ?>" method="post" class="d-inline">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin Data Akan dihapus ?')">Hapus</button>
                        </form>
            
                        <a href="/materials/<?php echo e($mtr->id); ?>" class="btn btn-info">Lihat</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\weblaravel\resources\views/materials/index.blade.php ENDPATH**/ ?>