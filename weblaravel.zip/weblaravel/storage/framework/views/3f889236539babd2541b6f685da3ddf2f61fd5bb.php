<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-4">
            <h1 class="mt-3">Detail Pegawai</h1>

            <div class="card">
                <div class="card-body">
                <h3 class="card-title"><b><?php echo e($pegawai->nama); ?></b></h3>
                <h5 class="card-title"><?php echo e($pegawai->jabatan); ?></h5>
                <h6 class="card-subtitle mb-2 text-muted"><u><?php echo e($pegawai->alamat); ?></u></h6>
                <p class="card-text"><b>Email </b><i><?php echo e($pegawai->email); ?></i></p>
                <p class="card-text"><b>No HP </b><?php echo e($pegawai->no_hp); ?></p>
                <a href="/pegawai/index" class="card-link">Kembali</a>
             
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\weblaravel\resources\views/pegawai/lihat.blade.php ENDPATH**/ ?>