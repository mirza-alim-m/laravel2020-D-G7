<?php $__env->startSection('content'); ?>
<div  style ="margin-top: 20px  " class="container">
<form action="<?php echo e(route('material.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group col-sm-4">
        <label>Kode Material</label>
        <input type="text" class="form-control" name="id"> 
    </div>
    <div class="form-group col-sm-4">
        <label>Nama Material</label>
        <input type="text" class="form-control" name="name">  
    </div class="form-group col-sm-4">
    <input class="btn btn-primary" type="submit" value="Tambahkan">

     <div>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\weblaravel\resources\views/create.blade.php ENDPATH**/ ?>