<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-4">
            <h1 class="mt-3">Detail Pelanggan</h1>

            <div class="card">
                <div class="card-body">
                <h4 class="card-title"><?php echo e($pelanggan->nama); ?></h4>
                <h6 class="card-subtitle mb-4 text-muted"><u><?php echo e($pelanggan->alamat); ?></u></h6>
                <p class="card-text"><b>Email </b><i><?php echo e($pelanggan->email); ?></i></p>
                <p class="card-text"><b>No HP </b><?php echo e($pelanggan->no_hp); ?></p>
                <a href="/pelanggan/index" class="card-link">Kembali</a>
             
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\weblaravel\resources\views/pelanggan/lihat.blade.php ENDPATH**/ ?>